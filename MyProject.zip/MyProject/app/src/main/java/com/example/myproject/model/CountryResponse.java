package com.example.myproject.model;

public class CountryResponse {
}
